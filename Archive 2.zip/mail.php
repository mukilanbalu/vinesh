<?php
error_reporting(-1);
ini_set('display_errors', 'On');
set_error_handler("var_dump");
    $to = 'victorrajkumar1@gmail.com';
    $email= $_POST["email"];
    $text= $_POST["message"];
    
  

    


    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= "From: " . $email . "\r\n"; // Sender's E-mail
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    $message ='<table style="width:100%">
       
        <tr><td>Email: '.$email.'</td></tr>
        <tr><td>Text: '.$text.'</td></tr>
        
    </table>';

    if (mail($to, $email, $message, $headers))
    {
        echo"<script> alert('Your message has been sent.') </script>";
        }else{
            echo"<script> alert('aMail sending failed') </script>";
    }

?>
